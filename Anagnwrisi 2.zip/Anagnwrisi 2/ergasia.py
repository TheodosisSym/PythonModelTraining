# -*- coding: utf-8 -*-

import numpy as nump
import sqlite3


####################################################################################################################
#Εισαγωγή: Παρακάτω διαβάζουμε τα δεδομένα από την βάση και τα επεξεργαζόμαστε ώστε να μπορεί να κατανοηθεί        #
#η εκφώνηση. Στην συνέχεια βλέπουμε με διαγράμματα το αρχικό πρόβλημα ταξινόμησης πριν την επίδραση των αλγορίθμων.#
####################################################################################################################

connsql = sqlite3.connect('database.sqlite')
crs = connsql.cursor()

qry = crs.execute("SELECT * FROM Match")
mtchs = []
y = []
X = []

caway=0
chome=0
cdraw=0


for match in qry:
    if None in match[-15:-3]:#metraei goals kai nikes
        continue
    t1 = match[9]-match[10]
    if t1 == 0:
        cdraw+=1
        y.append([-1,1,-1]) # [-1 h mia omada einai auti ,1 an exei isopalia -1 h alli omada] = Draw(D) Kai opou einai 1 simainei oti exei nikisei h omada h exei erthei isopalia
    elif t1 > 0:
        chome+=1
        y.append([1,-1,-1]) # [1 -1 -1] = Home(H)
    else:
        y.append([-1,-1,1]) # [-1 -1 1] = Away(A)
        caway+=1
    mtchs.append([match[7],match[8]]) # pairnei tis omades
    X.append(list(match[-15:-3]))#pernei ta gba

mtchs = nump.vstack(mtchs) # [[], []] => [[]]
                           # [[], []]    [[]] #ta kanei mia stili
X = nump.vstack(X)
y = nump.vstack(y)



print("D in dataset: ",cdraw/(cdraw+caway+chome)*100,"%")
print("A (wins) in dataset: ",caway/(cdraw+caway+chome)*100,"%")
print("H (wins) in dataset: ",chome/(cdraw+caway+chome)*100,"%")



qry = crs.execute("SELECT * FROM Team_Attributes GROUP BY team_api_id")
tms = []
for team in qry:
    tms.append([team[2],team[4],team[8],team[11],team[13],team[15],team[18],team[20],team[22]])# pernei ana toys arithmoys tis stiles
tms = nump.vstack(tms)# to stakarei pali

from sklearn.model_selection import train_test_split

xtrain, xtest, ytrain, ytest = train_test_split(list(zip(mtchs,X)), y, test_size=0.2)# to test size einai to possosto twn dedomenwn pou krataei gia na elenxei to modelo pou tha kanei train // me to zip enonei ta matchs me to X

mtchstrain, xtrain = zip(*xtrain)
mtchstrain = nump.vstack(list(mtchstrain))
xtrain = nump.vstack(list(xtrain))

mtchstest, xtest = zip(*xtest)
mtchstest = nump.vstack(list(mtchstest))
xtest = nump.vstack(list(xtest))

x1train = xtrain[:,0:3]
x2train = xtrain[:,3:6]   #oles oi grammes ap tin 3 mexri tin 6 stili se ola
x3train = xtrain[:,6:9]
x4train = xtrain[:,9:]

x1test = xtest[:,0:3]
x2test = xtest[:,3:6]
x3test = xtest[:,6:9]
x4test = xtest[:,9:]


cdraw=0
caway=0
chome=0
for x in ytrain.tolist():
    if x == [-1,1,-1]:
        cdraw +=1    #TA POSOSTA POU EKPEDEBEI TO MONDELO
    elif x == [1,-1,-1]:
        chome+=1
    else:
        caway+=1


print("D in train dataset: ",cdraw/(cdraw+caway+chome)*100,"%")
print("A (wins) in train dataset: ",caway/(cdraw+caway+chome)*100,"%")
print("H (wins) in train dataset: ",chome/(cdraw+caway+chome)*100,"%")




cdraw=0
caway=0
chome=0
for x in ytest.tolist():
    if x == [-1,1,-1]:
        cdraw +=1
    elif x == [1,-1,-1]:   # metraei to score pou exei to home to away kai tis isopalies TO APOTELESMA TWN POSOSTWN POY THA TESTAREI TO MONTELO
        chome+=1
    else:
        caway+=1


print("D in test dataset: ",cdraw/(cdraw+caway+chome)*100,"%")
print("A (wins) in test dataset: ",caway/(cdraw+caway+chome)*100,"%") # kai kanei ta posossta
print("H (wins) in test dataset: ",chome/(cdraw+caway+chome)*100,"%")


from sklearn.decomposition import PCA
import matplotlib.pyplot as matplt
####################################################################################################################
#############################################################Δημιουργία διαγραμμάτων ##PCA#####################################################################

pcaplt = PCA(n_components=2)
pcapltx = pcaplt.fit_transform(x1train)
pcapltx0 = []
pcapltx1 = []
pcapltx2 = []
for label,feature in zip(ytrain.tolist(),pcapltx):
    if label == [1,-1,-1]:
        pcapltx0.append(feature)
    elif label == [-1,1,-1]:
        pcapltx1.append(feature)
    else:
        pcapltx2.append(feature)
pcapltx0 = nump.vstack(pcapltx0)   # vstack ta dedomena giati to mondelo ta thelei me auton ton tropo             # KANEI TRAIN TO MONDELO
pcapltx1 = nump.vstack(pcapltx1)
pcapltx2 = nump.vstack(pcapltx2)
fig = matplt.figure() # ftiaxnei to figure (gia to PCA diagrama)
matplt.plot(pcapltx0[:,0],pcapltx0[:,1],'*')
matplt.plot(pcapltx1[:,0],pcapltx1[:,1],'>')
matplt.plot(pcapltx2[:,0],pcapltx2[:,1],'o')
matplt.legend(("HW","D","AW"))
matplt.show()

####################################################################################################################

#############################################################Δημιουργία διαγραμμάτων #LDA#####################################################################

from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
import matplotlib.pyplot as matplt
from mpl_toolkits.mplot3d import Axes3D

ynew = []
for label in ytrain.tolist():
    if label == [1,-1,-1]:
        ynew.append(0)
    elif label == [-1,1,-1]:
        ynew.append(1)
    else:
        ynew.append(2)
ldaplt = LinearDiscriminantAnalysis(n_components=2)
ldapltx = ldaplt.fit_transform(x1train,ynew)

ldapltx0 = []
ldapltx1 = []
ldapltx2 = []                                           #
for label,feature in zip(ytrain.tolist(),ldapltx):      #  Έτσι, συμπεραίνουμε ότι τα δεδομένα μας δεν είναι διαχωρίσιμα (γραμμικώς ή μη γραμμικώς) afou kanoume ta PCA kai LDA diagramata
    if label == [1,-1,-1]:                              #
        ldapltx0.append(feature)
    elif label == [-1,1,-1]:
        ldapltx1.append(feature)
    else:
        ldapltx2.append(feature)
ldapltx0 = nump.vstack(ldapltx0)
ldapltx1 = nump.vstack(ldapltx1)
ldapltx2 = nump.vstack(ldapltx2)
fig = matplt.figure()

matplt.plot(ldapltx0[:,0],ldapltx0[:,1],'*')
matplt.plot(ldapltx1[:,0],ldapltx1[:,1],'>')
matplt.plot(ldapltx2[:,0],ldapltx2[:,1],'o')
matplt.legend(("HW","D","AW"))
matplt.show()

####################################################################################################################
####################################################################################################################
#Ερώτημα1: Σε αυτό το ερώτημα υλοποιούμε τον αλγόριθμο Ελάχιστου Μέσου Τετραγωνικού Σφάλματος (LMSE). Στο          # Least mean square error  
#documentation περιγράφεται αναλυτικά η εκτέλεση και τελικά ποια εταιρεία οδήγησε σε μεγαλύτερη ακρίβεια ταξιν/σης.#
####################################################################################################################
####################################################################################################################


from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.utils import shuffle
import copy

class LeastMeanSquareClassifier(BaseEstimator, ClassifierMixin):
    """Classify samples based on the distance from the mean feature value"""
                                                       # max_iter= samples
    def __init__(self,max_iter=200,lr=0.001,tol=0.01): # tolerance= pithanotita error pou gia na stamatisei prepei na einai mikrotero apo aut
        self.w = nump.random.randn(3,3)                #lr= learning rate The learning rate is a hyperparameter that controls how much to change the model in response to the estimated error each time the model weights are updated
        self.max_iter = max_iter     
        self.lr = lr
        self.tol = tol

    def fit(self, X, y):  #ousiastika kanw train to model DILADI to fit simainei na kanei generate paromia data me auta pou tou kaname train
        self.w = nump.random.randn(3,3) #array filled with rrandom values[[0.34234],[0.5437],[0.353]]
        prev_j = 0                      

        for i in range(self.max_iter):
            dj = [[0,0,0],[0,0,0],[0,0,0]]
            J = 0                          #pithanotita
            for j in range(len(X)):
                dj += (2*(self.w.T @ nump.vstack(X[j])-nump.vstack(y[j]))*X[j])/len(X)   # Νομιζω φτιαχνω τα βαρη Auto poy kanei einai na afairei to X apo 
                J += sum((self.w.T @ X[j] - y[j])**2)/len(X)                             # to teliko apotelesma y kai na to diairei me to mikos tou X
            if abs(prev_j-J)<self.tol: #stamataei otan 
                break
            self.w -= self.lr*dj.T

            #print(J)
            prev_j = J
        return self


    def predict(self,X):
        preds = []
        for i in range(len(X)):
            t1 = (nump.abs(self.w.T @ X[i]-nump.ones((1,3),dtype = nump.int)[0])).argmin()# briskei toys diktes twn mikroterwn stoixeiwn tou array kai 
            if t1 == 0:                                                                   # analoga ti einai briskei poia omada nikise ston kathe agona
                pred = [1,-1,-1]  
            elif t1 == 1:
                pred = [-1,1,-1]
            else:
                pred = [-1,-1,1]
            preds.append(pred)
        return nump.vstack(preds)

    def score(self,X,y):
        preds = self.predict(X)
        l = (preds-y).tolist()
        s = 0
        for x in l:
            if x == [0,0,0]:
                s+=1
        result = s/len(y)
        return result

    def cross_validate(self, X, y,cv):
        t1 = list(zip(X,y))
        t1 = shuffle(t1)
        X,y = zip(*t1) #epistrefei to prwto stoixio apo to kathe keli tis listas
        X = nump.vstack(X)
        xparts = nump.array_split(X,cv)
        yparts = nump.array_split(y,cv) #spaei to array se multiple sub-arrays
        scores = []
        bestscore = 0
        for k in range(cv): #10 fold cross validation
            copy_xparts = copy.copy(xparts)
            copy_yparts = copy.copy(yparts)
            xtest = copy_xparts.pop(k)
            xtrain = nump.concatenate(copy_xparts)
            ytest = copy_yparts.pop(k)
            ytrain = nump.concatenate(copy_yparts)
            self.fit(xtrain,ytrain)
            foldscore = self.score(xtest,ytest)
            scores.append(foldscore)
            if k == 1:
                bestscore = foldscore
                bestw = self.w
            elif bestscore < foldscore:
                bestscore = foldscore
                bestw = self.w
            print("Validation score for fold ",k," : ",scores[k]*100,"%")
        result = sum(scores)/cv
        self.w = bestw
        return result


####################       Ο αλγόριθμος τρέχει με τα δεδομένα της πρώτης στοιχηματικής εταιρείας, χωρίς cross validation  ####################
####################	   (accuracy κάθε κλάσης ξεχωριστά). Παρατηρείται καλό ποσοστό στις HW περιπτώσεις,μέτριο ποσοστό ####################
####################	   στις AW περιπτώσεις και μέτριο ποσοστό στις D περιπτώσεις κάτι που είναι προφανές διότι τα     ####################
####################	   δεδομένα δεν είναι διαχωρίσιμα και υπάρχει και επικάλυψη.                                      ####################



lmse = LeastMeanSquareClassifier(max_iter=100,lr=0.02,tol=0.001)
lmse.fit(x1train,ytrain)
pred = lmse.predict(x1test)

################### Evaluate the model############################

c0 = c1 =c2 = c00 = c11 = c22 = 0
for l1,l2 in zip(pred.tolist(),ytest.tolist()):
    if  l2 == [1,-1,-1]:
        c0 += 1
        if l1 == [1,-1,-1]:
            c00 +=1
    elif l2 == [-1,1,-1]:
        c1 +=1
        if l1 == [-1,1,-1]:
            c11 +=1
    else:
        c2 +=1
        if l1 == [-1,-1,1]:
            c22 += 1
print("H accuracy :", c00/c0*100,"%")
print("D accuracy :", c11/c1*100,"%")
print("A accuracy :", c22/c2*100,"%")



lmse = LeastMeanSquareClassifier(max_iter=100,lr=0.02,tol=0.001)
cvscore = lmse.cross_validate(x1train,ytrain,10)
print("\nAverage CV score:",cvscore*100,"%\n")
print("LMSEC report for this test set: ",lmse.score(x1test,ytest)*100,"%")



lmse = LeastMeanSquareClassifier(max_iter=100,lr=0.018,tol=0.001)
cvscore = lmse.cross_validate(x2train,ytrain,10)
print("\nAverage CV score:",cvscore*100,"%\n")
print("LMSEC report for this test set: ",lmse.score(x2test,ytest)*100,"%")



lmse = LeastMeanSquareClassifier(max_iter=200,lr=0.018,tol=0.001)
cvscore = lmse.cross_validate(x3train,ytrain,10)
print("\nAverage CV score:",cvscore*100,"%\n")
print("LMSEC report for this test set: ",lmse.score(x3test,ytest)*100,"%")



lmse = LeastMeanSquareClassifier(max_iter=200,lr=0.02,tol=0.001)
cvscore = lmse.cross_validate(x4train,ytrain,10)
print("\nAverage CV score:",cvscore*100,"%\n")
print("LMSEC report for this test set: ",lmse.score(x4test,ytest)*100,"%")


####################################################################################################################
#Ερώτημα2: Σε αυτό το ερώτημα υλοποιούμε τον αλγόριθμο Ελάχιστου Τετραγωνικού Σφάλματος (LSE). Στοdocumentation    #
#περιγράφεται αναλυτικά η εκτέλεση και τελικά ποια εταιρεία οδήγησε σε μεγαλύτερη ακρίβεια ταξιν/σης.              #
####################################################################################################################



class LeastSquareClassifier():

    def __init__(self):
        self.w = []

    def fit(self,X,y):
        self.w = nump.linalg.inv(X.T @ X) @ X.T @ y # Linear Regression Equation //Απλή γραμμική παλινδρόμηση

        return self

    def predict(self,X):
        preds = []
        for i in range(len(X)):
            t1 = (nump.abs(self.w.T @ X[i]-nump.ones((1,3),dtype = nump.int)[0])).argmin()
            if t1 == 0:
                pred = [1,-1,-1]
            elif t1 == 1:
                pred = [-1,1,-1]
            else:
                pred = [-1,-1,1]
            preds.append(pred)
        return nump.vstack(preds)

    def score(self,X,y):
        preds = self.predict(X)
        l = (preds-y).tolist()
        s = 0
        for x in l:
            if x == [0,0,0]:
                s+=1
        result = s/len(y)
        return result

    def cross_validate(self, X, y,cv,rand=True):
        if rand:
            t1 = list(zip(X,y))
            t1 = shuffle(t1)
            X,y = zip(*t1)
        X = nump.vstack(X)
        xparts = nump.array_split(X,cv)
        yparts = nump.array_split(y,cv)
        scores = []
        bestscore = 0
        for k in range(0,cv):
            copy_xparts = copy.copy(xparts)
            copy_yparts = copy.copy(yparts)
            xtest = copy_xparts.pop(k)
            xtrain = nump.concatenate(copy_xparts)
            ytest = copy_yparts.pop(k)
            ytrain = nump.concatenate(copy_yparts)
            self.fit(xtrain,ytrain)
            foldscore = self.score(xtest,ytest)
            scores.append(foldscore)
            if k == 1:
                bestscore = foldscore
                bestw = self.w
            elif bestscore < foldscore:
                bestscore = foldscore
                bestw = self.w
            print("Validation ",k," : ",scores[k]*100,"%")
        result = sum(scores)/cv
        self.w = bestw
        return result



lmse = LeastSquareClassifier()
lmse.fit(x1train,ytrain)
pred = lmse.predict(x1test)

c0 = c1 =c2 = c00 = c11 = c22 = 0
for l1,l2 in zip(pred.tolist(),ytest.tolist()):
    if  l2 == [1,-1,-1]:
        c0 += 1
        if l1 == [1,-1,-1]:
            c00 +=1
    elif l2 == [-1,1,-1]:
        c1 +=1
        if l1 == [-1,1,-1]:
            c11 +=1
    else:
        c2 +=1
        if l1 == [-1,-1,1]:
            c22 += 1
print("H accuracy :", c00/c0*100,"%")
print("D accuracy :", c11/c1*100,"%")
print("A accuracy :", c22/c2*100,"%")



lse = LeastSquareClassifier()
cvscore = lse.cross_validate(x1train,ytrain,10)
print("\nAverage CV score:",cvscore*100,"%\n")
print("LMSEC report for this test set: ",lse.score(x1test,ytest)*100,"%")


lse = LeastSquareClassifier()
cvscore = lse.cross_validate(x2train,ytrain,10)
print("\nAverage CV score:",cvscore*100,"%\n")
print("LMSEC report for this test set: ",lse.score(x2test,ytest)*100,"%")



lse = LeastSquareClassifier()
cvscore = lse.cross_validate(x3train,ytrain,10)
print("\nAverage CV score:",cvscore*100,"%\n")
print("LMSEC report for this test set: ",lse.score(x3test,ytest)*100,"%")


lse = LeastSquareClassifier()
cvscore = lse.cross_validate(x4train,ytrain,10)
print("\nAverage CV score:",cvscore*100,"%\n")
print("LMSEC report for this test set: ",lse.score(x4test,ytest)*100,"%")


####################################################################################################################
#Ερώτημα3: Σε αυτό το ερώτημα υλοποιούμε πολυστρωματικό νευρωνικό δίκτυο. Στοdocumentation περιγράφεται αναλυτικά  #
#η εκτέλεση.#################################################################################################################



xtraintotal = []
ytrainnn = []
for i in range(len(xtrain)):
    hometeam = mtchstrain[i][0]
    awayteam = mtchstrain[i][1]
    crs = 0
    for x in tms:
        if x[0] == hometeam:
            t2 = x[1:]
            crs +=1
    for x in tms:
        if x[0] == awayteam:
            t3 = x[1:]
            crs +=1
    if crs == 2:
        xtraintotal.append(nump.concatenate((t2,t3,xtrain[i])))
        index = ytrain[i].argmax()
        t1 = nump.zeros((1,3),dtype = nump.int)[0]
        t1[index] = 1
        ytrainnn.append(t1)

ytrainnn = nump.vstack(ytrainnn)
xtraintotal = nump.vstack((xtraintotal))

ytestnn = []
xtesttotal = []
for i in range(len(xtest)):
    hometeam = mtchstest[i][0]
    awayteam = mtchstest[i][1]
    crs = 0
    for x in tms:
        if x[0] == hometeam:
            t2 = x[1:]
            crs +=1
    for x in tms:
        if x[0] == awayteam:
            t3 = x[1:]
            crs +=1
    if crs == 2:
        xtesttotal.append(nump.concatenate((t2,t3,xtest[i])))
        index = ytest[i].argmax()
        t1 = nump.zeros((1,3),dtype = nump.int)[0]
        t1[index] = 1
        ytestnn.append(t1)

ytestnn = nump.vstack(ytestnn)
xtesttotal = nump.vstack((xtesttotal))


from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
import matplotlib.pyplot as matplt

#############################################################Δημιουργία διαγραμμάτων #LDA#####################################################################

ynew = []
for label in ytrainnn.tolist():
    if label == [1,0,0]:
        ynew.append(0)
    elif label == [0,1,0]:
        ynew.append(1)
    else:
        ynew.append(2)
ldaplt = LinearDiscriminantAnalysis(n_components=2)
ldapltx = ldaplt.fit_transform(xtraintotal,ynew)

ldapltx0 = []
ldapltx1 = []
ldapltx2 = []
for label,feature in zip(ytrainnn.tolist(),ldapltx):
    if label == [1,0,0]:
        ldapltx0.append(feature)
    elif label == [0,1,0]:
        ldapltx1.append(feature)
    else:
        ldapltx2.append(feature)
ldapltx0 = nump.vstack(ldapltx0)
ldapltx1 = nump.vstack(ldapltx1)
ldapltx2 = nump.vstack(ldapltx2)
fig = matplt.figure()

matplt.plot(ldapltx0[:,0],ldapltx0[:,1],'*')
matplt.plot(ldapltx1[:,0],ldapltx1[:,1],'>')
matplt.plot(ldapltx2[:,0],ldapltx2[:,1],'o')
matplt.legend(("HW","D","AW"))
matplt.show()


#############################################################Δημιουργία διαγραμμάτων #PCA#####################################################################

from sklearn.decomposition import PCA

pcaplt = PCA(n_components=2)
pcapltx = pcaplt.fit_transform(xtraintotal)
pcapltx0 = []
pcapltx1 = []
pcapltx2 = []
for label,feature in zip(ytrainnn.tolist(),pcapltx):
    if label == [1,0,0]:
        pcapltx0.append(feature)
    elif label == [0,1,0]:
        pcapltx1.append(feature)
    else:
        pcapltx2.append(feature)
pcapltx0 = nump.vstack(pcapltx0)
pcapltx1 = nump.vstack(pcapltx1)
pcapltx2 = nump.vstack(pcapltx2)
fig = matplt.figure()
matplt.plot(pcapltx0[:,0],pcapltx0[:,1],'*')
matplt.plot(pcapltx1[:,0],pcapltx1[:,1],'>')
matplt.plot(pcapltx2[:,0],pcapltx2[:,1],'o')
matplt.legend(("HW","D","AW"))
matplt.show()

###################################################################Δημιουργία #MLP###########################################################################

import math

class NN():
    def __init__(self,inumput_size=28,hidden_layer_size=10,output_size=3,lr = 0.001):
        self.hidden_layer_size = hidden_layer_size
        self.hidden_nodes_values = []
        self.hidden_nodes_outputs = []
        self.inumput_size = inumput_size
        self.output_size = output_size
        self.weights = [nump.random.randn(inumput_size,hidden_layer_size),nump.random.randn(hidden_layer_size,output_size)]
        self.probs = []
        self.lr = lr
        self.outin = []

    def forward(self,x):
        out = []
        self.probs = []
        self.hidden_nodes_outputs = []

        self.hidden_nodes_values = x@self.weights[0]
        for h in self.hidden_nodes_values:
            self.hidden_nodes_outputs.append(self.activation_fn(h))

        self.outin = self.hidden_nodes_outputs@self.weights[1]

        for h in self.outin:
            self.probs.append(self.softmax(h))
        for p in self.probs:
            t1 = nump.array(p).argmax()
            t3 = nump.zeros((1,self.output_size))[0].astype('int32')
            t3[t1] = 1
            out.append(t3)

        return nump.vstack(out).astype('int32')

    def activation_fn(self,hv):
        res = []
        for value in hv:
            res.append(1/(1+nump.exp(-value,dtype = nump.longdouble)))
        return res

    def softmax(self,x):
        s = sum(nump.exp(x))
        return nump.exp(x)/s

    def backward(self,out,y,X):
        dj1 = nump.zeros((self.inumput_size,self.hidden_layer_size))
        dj2 = nump.zeros((self.hidden_layer_size,self.output_size))
        for sample in range(len(X)):
            dmse = 2*(self.probs[sample]-y[sample])
            for i in range(self.output_size):
                for j in range(self.hidden_layer_size):
                    dj2[j][i] += dmse[i]*self.hidden_nodes_outputs[sample][j]*(nump.exp(self.outin[sample][i])*                                (sum(nump.exp(self.outin[sample]))-nump.exp(self.outin[sample][i])))/(sum(nump.exp(self.outin[sample]))**2)
            for i in range(self.hidden_layer_size):
                dmse2 = 0
                for o in range(self.output_size):
                    dmse2 += dmse[o]*self.weights[1][i][o]*(nump.exp(self.outin[sample][o])*                                (sum(nump.exp(self.outin[sample]))-nump.exp(self.outin[sample][o])))/(sum(nump.exp(self.outin[sample]))**2)
                for j in range(self.inumput_size):
                    dj1[j][i] += (dmse2)*X[sample][j]*self.hidden_nodes_outputs[sample][i]*(1-self.hidden_nodes_outputs[sample][i])
        self.weights[0] -= self.lr*dj1/len(X)
        self.weights[1] -= self.lr*dj2/len(X)
        return sum(sum(self.probs-y)**2)/len(X)


xtrain2, xvalidation, ytrain2, yvalidation = train_test_split(xtraintotal, ytrainnn, test_size=0.1)
nn = NN(hidden_layer_size=5,lr = 0.005)
eras = 10
batch_size = 150
for era in range(eras):
    t1 = list(zip(xtrain2,ytrain2))
    t1 = shuffle(t1)
    tempx,tempy = zip(*t1)
    batchesx = nump.array_split(tempx,len(tempx)//batch_size)
    batchesy = nump.array_split(tempy,len(tempy)//batch_size)
    loss = 0
    prevloss = 0
    for batchx,batchy in zip(batchesx,batchesy):
        preds = nn.forward(batchx)
        loss += nn.backward(preds,batchy,batchx)
    print("Train loss for era",era,":",loss)
    preds = nn.forward(xvalidation)
    crs = 0
    for pred,label in zip(preds,yvalidation):
        if list(pred) == list(label):
            crs += 1
    print("Validation for era",era,":", crs/len(preds)*100,"%")
    prevloss = loss


preds = nn.forward(xtesttotal)
crs = 0
for pred,label in zip(preds,ytestnn):
    if list(pred) == list(label):
        crs += 1
print("Test report:", crs/len(preds)*100,"%")


#############################################################Δημιουργία PCA#####################################################################

pcaplt = PCA(n_components=16)
pcapltx = pcaplt.fit_transform(xtraintotal)

#############################################################Δημιουργία διαγραμμάτων LDA on PCA#################################################
ynew = []
for label in ytrainnn.tolist():
    if label == [1,0,0]:
        ynew.append(0)
    elif label == [0,1,0]:
        ynew.append(1)
    else:
        ynew.append(2)
ldaplt = LinearDiscriminantAnalysis(n_components=2)
ldapltx = ldaplt.fit_transform(pcapltx,ynew)

ldapltx0 = []
ldapltx1 = []
ldapltx2 = []
for label,feature in zip(ytrainnn.tolist(),ldapltx):
    if label == [1,0,0]:
        ldapltx0.append(feature)
    elif label == [0,1,0]:
        ldapltx1.append(feature)
    else:
        ldapltx2.append(feature)
ldapltx0 = nump.vstack(ldapltx0)
ldapltx1 = nump.vstack(ldapltx1)
ldapltx2 = nump.vstack(ldapltx2)
fig = matplt.figure()

matplt.plot(ldapltx0[:,0],ldapltx0[:,1],'*')
matplt.plot(ldapltx1[:,0],ldapltx1[:,1],'>')
matplt.plot(ldapltx2[:,0],ldapltx2[:,1],'o')
matplt.legend(("HW","D","AW"))
matplt.show()




xtrain2, xvalidation, ytrain2, yvalidation = train_test_split(ldapltx, ytrainnn, test_size=0.1)
nn = NN(inumput_size=2,hidden_layer_size=5,lr = 0.02)
eras = 20
batch_size = 100
for era in range(eras):
    t1 = list(zip(xtrain2,ytrain2))
    t1 = shuffle(t1)
    tempx,tempy = zip(*t1)
    batchesx = nump.array_split(tempx,len(tempx)//batch_size)
    batchesy = nump.array_split(tempy,len(tempy)//batch_size)
    loss = 0
    prevloss = 0
    for batchx,batchy in zip(batchesx,batchesy):
        preds = nn.forward(batchx)
        loss += nn.backward(preds,batchy,batchx)
    print("Train loss for era",era,":",loss)
    preds = nn.forward(xvalidation)
    crs = 0
    for pred,label in zip(preds,yvalidation):
        if list(pred) == list(label):
            crs += 1
    print("Validation for era",era,":", crs/len(preds)*100,"%")
    prevloss = loss



pcaplt = PCA(n_components=16)
pcapltx = pcaplt.fit_transform(xtesttotal)

ynew = []
for label in ytestnn.tolist():
    if label == [1,0,0]:
        ynew.append(0)
    elif label == [0,1,0]:
        ynew.append(1)
    else:
        ynew.append(2)

ldaplt = LinearDiscriminantAnalysis(n_components=2)
ldapltx = ldaplt.fit_transform(pcapltx,ynew)

preds = nn.forward(ldapltx)
crs = 0
for pred,label in zip(preds,ytestnn):
    if list(pred) == list(label):
        crs += 1
print("Test report:", crs/len(preds)*100,"%")
